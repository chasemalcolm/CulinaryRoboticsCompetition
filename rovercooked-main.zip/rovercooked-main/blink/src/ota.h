#pragma once

// Call after Wifi is enabled.
void initOTA();

// In main loop call ArduinoOTA.handle()
