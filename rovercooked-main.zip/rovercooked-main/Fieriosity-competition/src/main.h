#pragma once

void deluxeCheeseBurgerAndFries(bool fromStart=true);
void cheesePlate(bool fromStart=true);
void salad(bool fromStart=true);
void twoSalad(bool fromStart=true);
void deluxeCheeseBurgerAndFriesThenFries();
void deluxeCheeseBurgerAndFriesThenSalad();