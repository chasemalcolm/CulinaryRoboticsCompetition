#pragma once

void initButtonPanel();

void tickButtonPanel();